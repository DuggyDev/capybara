package net.capybarasmp.scoreboard;

import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class BoardManager {

    private static final String[] KEYS = {"kills", "deaths", "money", "playtime", "lives"};
    private static final String[] DEFAULTS = {
            "<red>⚔ <white>Kills <red><value>",
            "<gold>☠ <white>Deaths <gold><value>",
            "<green>$ <white>Money <green><value>",
            "<yellow>⏱ <white>Playtime <yellow><value>",
            "<red>❤ <white>Lives <red><value>"
    };
    // Invisible, unique entry names (color codes render as nothing)
    private static final String[] ENTRIES = {"\u00a70", "\u00a71", "\u00a72", "\u00a73", "\u00a74"};

    private final CapybaraScoreboard plugin;
    private final DataManager data;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public BoardManager(CapybaraScoreboard plugin, DataManager data) {
        this.plugin = plugin;
        this.data = data;
    }

    public void show(Player player) {
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Component title = mm.deserialize(plugin.getConfig().getString("scoreboard.title", "<bold><aqua>CAPYBARA SMP"));
        Objective obj = board.registerNewObjective("capybara", Criteria.DUMMY, title);
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.numberFormat(NumberFormat.blank());

        for (int i = 0; i < KEYS.length; i++) {
            Team team = board.registerNewTeam("line" + i);
            team.addEntry(ENTRIES[i]);
            obj.getScore(ENTRIES[i]).setScore(KEYS.length - i);
        }

        boards.put(player.getUniqueId(), board);
        player.setScoreboard(board);
        update(player);
    }

    public void remove(Player player) {
        boards.remove(player.getUniqueId());
    }

    public void reload() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            show(p);
        }
    }

    public void update(Player player) {
        Scoreboard board = boards.get(player.getUniqueId());
        if (board == null) return;
        PlayerData d = data.get(player.getUniqueId());

        String[] values = {
                String.valueOf(d.kills),
                String.valueOf(d.deaths),
                MoneyUtil.format(d.money),
                formatPlaytime(d.playtimeSeconds),
                String.valueOf(d.lives)
        };

        for (int i = 0; i < KEYS.length; i++) {
            Team team = board.getTeam("line" + i);
            if (team == null) continue;
            String template = plugin.getConfig().getString("scoreboard.lines." + KEYS[i], DEFAULTS[i]);
            Component line = mm.deserialize(template, Placeholder.unparsed("value", values[i]));
            if (!line.equals(team.prefix())) {
                team.prefix(line);
            }
        }
    }

    public String formatPlaytime(long totalSeconds) {
        long hours = totalSeconds / 3600;
        long minutes = (totalSeconds % 3600) / 60;
        if (hours > 0 || plugin.getConfig().getBoolean("scoreboard.always-show-hours", true)) {
            return hours + "h " + minutes + "m";
        }
        return minutes + "m";
    }
}
